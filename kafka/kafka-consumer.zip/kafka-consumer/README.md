# Kafka Consumer - Spring Boot

Pairs directly with the kafka-producer app.
Same topic (my-topic), same broker (localhost:9092), same serialization (String).

## Prerequisites
- Java 17+
- Maven 3.8+
- Kafka running on localhost:9092
- kafka-producer app (to send messages to consume)

## Run Kafka Locally (Docker)
```bash
docker run -d --name kafka \
  -p 9092:9092 \
  -e KAFKA_CFG_NODE_ID=0 \
  -e KAFKA_CFG_PROCESS_ROLES=controller,broker \
  -e KAFKA_CFG_LISTENERS=PLAINTEXT://:9092,CONTROLLER://:9093 \
  -e KAFKA_CFG_LISTENER_SECURITY_PROTOCOL_MAP=CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT \
  -e KAFKA_CFG_CONTROLLER_QUORUM_VOTERS=0@localhost:9093 \
  -e KAFKA_CFG_CONTROLLER_LISTENER_NAMES=CONTROLLER \
  bitnami/kafka:latest
```

## Build & Run
```bash
mvn clean install
mvn spring-boot:run
```

## Run Multiple Instances (EC2 Scaling Simulation)
```bash
# Terminal 1 - Instance 1
mvn spring-boot:run -Dspring-boot.run.arguments="--server.port=8081"

# Terminal 2 - Instance 2
mvn spring-boot:run -Dspring-boot.run.arguments="--server.port=8082"

# Terminal 3 - Instance 3
mvn spring-boot:run -Dspring-boot.run.arguments="--server.port=8083"
```
Kafka will auto-distribute the 3 topic partitions across all 3 instances.

## Producer + Consumer Together
1. Start Kafka
2. Start kafka-producer (port 8080)
3. Start kafka-consumer (port 8081)
4. Send a message via producer:
   curl -X POST "http://localhost:8080/api/kafka/send?message=HelloFromProducer"
5. Watch kafka-consumer logs — message appears instantly

## Listener Types
- Basic listener     → one message at a time, group: my-consumer-group
- Batch listener     → up to 10 messages at once, group: batch-consumer-group
- Partition listener → only reads partition 0, group: partition-specific-group
