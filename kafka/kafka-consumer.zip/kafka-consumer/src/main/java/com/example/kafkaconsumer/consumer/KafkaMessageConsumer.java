package com.example.kafkaconsumer.consumer;

import com.example.kafkaconsumer.service.MessageProcessorService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class KafkaMessageConsumer {

    private final MessageProcessorService processorService;

    /**
     * 1️⃣ BASIC LISTENER
     * Consumes messages one at a time from "my-topic"
     * — same topic the producer sends to.
     * Manual ack ensures offset is committed only after successful processing.
     */
    @KafkaListener(
        topics = "${app.kafka.topic}",
        groupId = "${spring.kafka.consumer.group-id}",
        containerFactory = "kafkaListenerContainerFactory"
    )
    public void consume(
            @Payload String message,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
            @Header(KafkaHeaders.OFFSET) long offset,
            @Header(KafkaHeaders.RECEIVED_KEY) String key,
            Acknowledgment acknowledgment) {

        log.info("📨 Received | Partition: {} | Offset: {} | Key: {} | Message: {}",
                partition, offset, key, message);

        try {
            processorService.process(message);
            acknowledgment.acknowledge(); // ✅ commit offset only on success
            log.info("✅ Processed and acknowledged | Offset: {}", offset);
        } catch (Exception e) {
            log.error("❌ Failed to process message at offset {}: {}", offset, e.getMessage());
            // Do NOT acknowledge — DefaultErrorHandler will retry
        }
    }

    /**
     * 2️⃣ BATCH LISTENER
     * Consumes up to max-poll-records (10) messages in one go.
     * More efficient for high-throughput scenarios.
     */
    @KafkaListener(
        topics = "${app.kafka.topic}",
        groupId = "batch-consumer-group",
        containerFactory = "batchKafkaListenerContainerFactory"
    )
    public void consumeBatch(
            List<ConsumerRecord<String, String>> records,
            Acknowledgment acknowledgment) {

        log.info("📦 Batch received: {} messages", records.size());

        records.forEach(record ->
            log.info("  ↳ Partition: {} | Offset: {} | Key: {} | Value: {}",
                record.partition(), record.offset(), record.key(), record.value())
        );

        // Process all records in the batch
        records.forEach(record -> processorService.process(record.value()));

        acknowledgment.acknowledge(); // commit entire batch at once
        log.info("✅ Batch of {} messages acknowledged", records.size());
    }

    /**
     * 3️⃣ PARTITION-SPECIFIC LISTENER
     * Only reads from Partition 0.
     * Useful for priority lanes or ordered processing of specific data.
     */
    @KafkaListener(
        groupId = "partition-specific-group",
        topicPartitions = @TopicPartition(
            topic = "${app.kafka.topic}",
            partitions = {"0"}
        )
    )
    public void consumeFromPartitionZero(
            @Payload String message,
            @Header(KafkaHeaders.OFFSET) long offset,
            Acknowledgment acknowledgment) {

        log.info("🎯 Partition-0 only | Offset: {} | Message: {}", offset, message);
        processorService.process(message);
        acknowledgment.acknowledge();
    }
}
