package com.example.kafkaconsumer.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class MessageProcessorService {

    /**
     * Core business logic after receiving a Kafka message.
     * Replace the body with your actual logic:
     *   - Save to database
     *   - Call downstream REST API
     *   - Trigger another Kafka message
     *   - Transform and forward data
     */
    public void process(String message) {
        if (message == null || message.isBlank()) {
            throw new IllegalArgumentException("Received blank message — skipping");
        }

        log.info("⚙️  Processing message: {}", message);

        // ── Add your business logic below ──────────────────────────────────

        // Example: Save to DB
        // orderRepository.save(parseOrder(message));

        // Example: Call another service
        // notificationService.notify(message);

        // Example: Forward to another topic
        // kafkaTemplate.send("another-topic", message);

        // ───────────────────────────────────────────────────────────────────

        log.info("✅ Business logic complete for: {}", message);
    }
}
