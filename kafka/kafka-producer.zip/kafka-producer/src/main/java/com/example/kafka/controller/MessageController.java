package com.example.kafka.controller;

import com.example.kafka.service.KafkaProducerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/kafka")
@RequiredArgsConstructor
public class MessageController {

    private final KafkaProducerService producerService;

    /**
     * Send a simple message (no key, round-robin partition)
     * POST /api/kafka/send?message=HelloKafka
     */
    @PostMapping("/send")
    public ResponseEntity<String> send(@RequestParam String message) {
        producerService.sendMessage(message);
        return ResponseEntity.ok("Message sent: " + message);
    }

    /**
     * Send a message with a key (ordered per key)
     * POST /api/kafka/send-with-key?key=user-1&message=Hello
     */
    @PostMapping("/send-with-key")
    public ResponseEntity<String> sendWithKey(
            @RequestParam String key,
            @RequestParam String message) {
        producerService.sendMessageWithKey(key, message);
        return ResponseEntity.ok("Sent with key='" + key + "': " + message);
    }

    /**
     * Send a message to a specific partition
     * POST /api/kafka/send-to-partition?partition=0&key=k1&message=Hi
     */
    @PostMapping("/send-to-partition")
    public ResponseEntity<String> sendToPartition(
            @RequestParam int partition,
            @RequestParam String key,
            @RequestParam String message) {
        producerService.sendToPartition(partition, key, message);
        return ResponseEntity.ok("Sent to partition " + partition + ": " + message);
    }
}
