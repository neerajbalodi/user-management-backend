package com.example.kafka.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class KafkaProducerService {

    private final KafkaTemplate<String, String> kafkaTemplate;

    @Value("${app.kafka.topic}")
    private String topicName;

    /**
     * Send a message with no key.
     * Kafka distributes messages across partitions using round-robin.
     */
    public void sendMessage(String message) {
        kafkaTemplate.send(topicName, message)
                .whenComplete((result, ex) -> {
                    if (ex == null) {
                        log.info("✅ Sent: '{}' | Partition: {} | Offset: {}",
                                message,
                                result.getRecordMetadata().partition(),
                                result.getRecordMetadata().offset());
                    } else {
                        log.error("❌ Failed to send message '{}': {}", message, ex.getMessage());
                    }
                });
    }

    /**
     * Send a message with a key.
     * Messages with the same key always go to the same partition,
     * guaranteeing ordering per key (e.g., per userId).
     */
    public void sendMessageWithKey(String key, String message) {
        kafkaTemplate.send(topicName, key, message)
                .whenComplete((result, ex) -> {
                    if (ex == null) {
                        log.info("✅ Sent key='{}' msg='{}' | Partition: {} | Offset: {}",
                                key, message,
                                result.getRecordMetadata().partition(),
                                result.getRecordMetadata().offset());
                    } else {
                        log.error("❌ Failed to send key='{}': {}", key, ex.getMessage());
                    }
                });
    }

    /**
     * Send a message directly to a specific partition.
     * Use when you need full control over partition routing.
     */
    public void sendToPartition(int partition, String key, String message) {
        kafkaTemplate.send(topicName, partition, key, message)
                .whenComplete((result, ex) -> {
                    if (ex == null) {
                        log.info("✅ Sent to partition {}: '{}' | Offset: {}",
                                partition, message,
                                result.getRecordMetadata().offset());
                    } else {
                        log.error("❌ Failed to send to partition {}: {}", partition, ex.getMessage());
                    }
                });
    }
}
