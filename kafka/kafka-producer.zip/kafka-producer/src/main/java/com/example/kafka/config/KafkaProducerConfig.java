package com.example.kafka.config;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;

@Configuration
public class KafkaProducerConfig {

    @Value("${app.kafka.topic}")
    private String topicName;

    /**
     * Auto-creates the Kafka topic if it does not already exist.
     * partitions(3) - splits data across 3 partitions for parallelism
     * replicas(1)   - 1 replica (use 3 in production for fault tolerance)
     */
    @Bean
    public NewTopic createTopic() {
        return TopicBuilder.name(topicName)
                .partitions(3)
                .replicas(1)
                .build();
    }
}
