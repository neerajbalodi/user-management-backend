# Kafka Producer - Spring Boot

A simple Spring Boot Kafka Producer application.

## Prerequisites
- Java 17+
- Maven 3.8+
- Apache Kafka running on `localhost:9092`

## Run Kafka Locally (Docker)
```bash
docker run -d --name kafka \
  -p 9092:9092 \
  -e KAFKA_CFG_NODE_ID=0 \
  -e KAFKA_CFG_PROCESS_ROLES=controller,broker \
  -e KAFKA_CFG_LISTENERS=PLAINTEXT://:9092,CONTROLLER://:9093 \
  -e KAFKA_CFG_LISTENER_SECURITY_PROTOCOL_MAP=CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT \
  -e KAFKA_CFG_CONTROLLER_QUORUM_VOTERS=0@localhost:9093 \
  -e KAFKA_CFG_CONTROLLER_LISTENER_NAMES=CONTROLLER \
  bitnami/kafka:latest
```

## Build & Run
```bash
mvn clean install
mvn spring-boot:run
```

## API Endpoints

### 1. Send Simple Message
```bash
curl -X POST "http://localhost:8080/api/kafka/send?message=HelloKafka"
```

### 2. Send With Key (ordered delivery per key)
```bash
curl -X POST "http://localhost:8080/api/kafka/send-with-key?key=user-1&message=Hello"
```

### 3. Send to Specific Partition
```bash
curl -X POST "http://localhost:8080/api/kafka/send-to-partition?partition=0&key=k1&message=Hi"
```

## Verify Messages via CLI
```bash
kafka-console-consumer.sh \
  --bootstrap-server localhost:9092 \
  --topic my-topic \
  --from-beginning
```
